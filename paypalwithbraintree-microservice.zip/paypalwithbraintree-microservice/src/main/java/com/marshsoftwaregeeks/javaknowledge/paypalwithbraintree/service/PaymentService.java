package com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree.service;

import com.braintreegateway.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentService {


    private BraintreeGateway gateway;

    public PaymentService(
            @Value("${braintree.merchantId}") String merchantId,
            @Value("${braintree.publicKey}") String publicKey,
            @Value("${braintree.privateKey}") String privateKey,
            @Value("${braintree.environment}") String environment
    ) {
        this.gateway = new BraintreeGateway(
                environment.equals("SANDBOX") ? Environment.SANDBOX : Environment.PRODUCTION,
                merchantId,
                publicKey,
                privateKey
        );
    }

    public Map<String, String> generateClientToken() {
        ClientTokenRequest clientTokenRequest = new ClientTokenRequest();
        String token = gateway.clientToken().generate(clientTokenRequest);
        //System.out.println("clientToken"+token);
        HashMap<String, String> map = new HashMap<>();
        map.put("clientToken", token);
        return map;
        //return Collections.singletonMap("clientToken", token);
    }

    public boolean makePayment(BigDecimal amount, String nonce) {
        System.out.println("Has nonce been formed"+nonce);
        TransactionRequest request = new TransactionRequest()
                .amount(amount)
                .paymentMethodNonce(nonce)
                .options()
                .submitForSettlement(true)
                .done();

        Result<Transaction> result = gateway.transaction().sale(request);
        if (result.isSuccess()) {
            System.out.println("Transaction ID: " + result.getTarget().getId());
            return true;
        } else {
                 System.err.println("Transaction failed: " + result.getMessage());

            if (result.getTransaction() != null) {
                System.err.println("Transaction status: " + result.getTransaction().getStatus());
            }

            if (result.getTransaction() != null) {
                Transaction transaction = result.getTransaction();
                System.err.println("Transaction ID: " + transaction.getId());
                System.err.println("Status: " + transaction.getStatus());
                System.err.println("Processor Response Code: " + transaction.getProcessorResponseCode());
                System.err.println("Processor Response Text: " + transaction.getProcessorResponseText());
            } else {
                System.err.println("No transaction was created. Probably a gateway-level error.");
            }


            System.err.println("Validation errors:");
            for (ValidationError error : result.getErrors().getAllDeepValidationErrors()) {
                System.err.println("Error Code: " + error.getCode());
                System.err.println("Error Message: " + error.getMessage());
            }

            return false;
        }
    }
}