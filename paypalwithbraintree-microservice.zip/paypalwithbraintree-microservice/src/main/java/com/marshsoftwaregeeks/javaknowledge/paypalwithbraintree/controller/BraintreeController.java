package com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree.controller;


import com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree.model.CheckoutRequest;
import com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins = "*")
@Controller
@RequestMapping("/payments")
public class BraintreeController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/checkout")
    public String showCheckoutPage(Model model) {
        String token = paymentService.generateClientToken().get("clientToken");
      //  System.out.println("In Controller Class clientToken"+token);
        model.addAttribute("clientToken", token);
        return "checkout";
        //return "index";
    }

    @PostMapping("/checkout")
    @ResponseBody
    public ResponseEntity<?> handleCheckout(@RequestBody CheckoutRequest request) {
        boolean success = paymentService.makePayment(request.getAmount(), request.getPaymentMethodNonce());

        if (success) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/success")
    public String successPage() {
        return "success";
    }

    @GetMapping("/failure")
    public String failurePage() {
        return "failure";
    }
}