package com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "braintree")
@Data
public class BraintreeProperties {

    private String merchantId;
    private String publicKey;
    private String privateKey;
    private String environment;
}
