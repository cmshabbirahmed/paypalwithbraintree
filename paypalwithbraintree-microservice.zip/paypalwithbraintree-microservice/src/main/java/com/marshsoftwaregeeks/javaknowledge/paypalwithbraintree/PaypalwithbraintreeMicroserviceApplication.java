package com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaypalwithbraintreeMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaypalwithbraintreeMicroserviceApplication.class, args);
	}

}
