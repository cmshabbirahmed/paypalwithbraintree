package com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree.config;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BraintreeConfiguration {


//    @Value("${braintree.merchantId}") String merchantId;
//    @Value("${braintree.publicKey}") String publicKey;
//    @Value("${braintree.privateKey}") String privateKey;
//    @Value("${braintree.environment}") String env;
//
//    //Environment environment = Environment.SANDBOX; // default
//
//    @Bean
//    public BraintreeGateway gateway() {
//        Environment environment;
//        switch (env.toUpperCase()) {
//            case "PRODUCTION":
//                environment = Environment.PRODUCTION;
//                break;
//            case "DEVELOPMENT":
//                environment = Environment.DEVELOPMENT;
//                break;
//            case "SANDBOX":
//            default:
//                environment = Environment.SANDBOX;
//                break;
//        }
//
//        return new BraintreeGateway(environment, merchantId, publicKey, privateKey);
//    }

    @Autowired
    private BraintreeProperties props;

    @Bean
    public BraintreeGateway gateway() {
        Environment environment = switch (props.getEnvironment().toUpperCase()) {
            case "PRODUCTION" -> Environment.PRODUCTION;
            case "DEVELOPMENT" -> Environment.DEVELOPMENT;
            default -> Environment.SANDBOX;
        };
        return new BraintreeGateway(environment, props.getMerchantId(), props.getPublicKey(), props.getPrivateKey());
    }
}


