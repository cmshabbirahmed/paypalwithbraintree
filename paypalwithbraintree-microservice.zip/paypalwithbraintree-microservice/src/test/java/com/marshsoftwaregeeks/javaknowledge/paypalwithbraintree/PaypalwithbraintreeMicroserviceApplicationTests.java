package com.marshsoftwaregeeks.javaknowledge.paypalwithbraintree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaypalwithbraintreeMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
